from flask import Flask,render_template,request,flash
from torchvision import models
import torchvision.transforms as transforms
import torch.nn as nn
import io
import json
import torch
from torchvision import models
import torchvision.transforms as transforms
from PIL import Image
from flask import Flask, jsonify, request
import os
from werkzeug.utils import secure_filename
from PIL import Image
from torch.utils.data import Dataset
import numpy as np
#differentiation library that supports all differentiable Tensor operations in torch
from torch.autograd import Variable
import cv2


from torchvision.utils import save_image

import torchvision

UPLOAD_FOLDER = './saved/'

from net2d import Net2D
import pickle

root_path = '/media/darsh/DATA1/B TECH/YEAR FOUR/Semester1/Visual_Computing_Lab/MidTermProj/flask_website'

app = Flask(__name__)
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


#################################################


# Python fuction to read dataset as described on CIFAR 10 website
def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


#################################################

class CPU_Unpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module == 'torch.storage' and name == '_load_from_bytes':
            return lambda b: torch.load(io.BytesIO(b), map_location='cpu')
        else:
            return super().find_class(module, name)



weights = CPU_Unpickler(open('model_mid_lr_0_0005_20_epoch_trial_2.pkl','rb')).load()

fixed_model_2d_loaded = Net2D()

cnt=0
for ijk in fixed_model_2d_loaded.parameters():
  ijk.data = weights[cnt]
  cnt+=1

##################################################

metaData = unpickle('cifar-100-python/meta')#metaData
print("Fine labels:", metaData[b'fine_label_names'], "\n")

print(metaData[b'fine_label_names'][16])

##################################################
class CustomDataset(Dataset):
    

    def __init__(self, root, train=True, transform=None):
        self.root = root
        self.transform = transform
        self.train = train

        self.load_data()

    def load_data(self):
        
        # directory_str = "/content/cifar-100-batches-py"
        directory = os.fsencode(self.root)

        images = []
        labels = []

        for file in os.listdir(directory):
            filename = os.fsdecode(file)


            if filename.endswith(".asm") or filename.endswith(".py"): 
                # print(os.path.join(directory, filename))
                continue
            else:
                # train = False
                dataPath = self.root+'/'+filename
                # print(dataPath)
                if self.train==True and filename =="train":
                  # print("t>>" + dataPath)  
                  images_dict = unpickle(dataPath)
                  
                  # n_iter = 2

                  for k in range(0,len(images_dict[b'data'])):
                    # if(n_iter>0):
                      # print(k)
                      if int(images_dict[b'fine_labels'][k] )<=25 and int(images_dict[b'fine_labels'][k] )>=16:

                        img_R = images_dict[b'data'][k][0:1024].reshape((32, 32))
                        img_G = images_dict[b'data'][k][1024:2048].reshape((32, 32))
                        img_B = images_dict[b'data'][k][2048:3072].reshape((32, 32))
                        img = np.dstack((img_R, img_G, img_B))
                        # plt.figure()
                        img = transforms.ToPILImage()(img )                      
                        # transforms.ToPILImage(img)    
                        images.append(img)

                        
                        labels.append( int(images_dict[b'fine_labels'][k] )  - 16 )
                        
                      # images.append(transforms.ToPILImage(img))

                      # plt.imshow(img)
                      # n_iter-=1

                    # else:
                      # break
                  
                  # n_iter = 2
                  # for k in range(0,len(images_dict[b'labels'])):
                    # if(n_iter>0):
                      # print(k)
                      # n_iter-=1
                      
                    
                    # else:
                      # break
                    
            
                  # continue

                elif self.train==False and filename =="test":

                  # print("t>>" + dataPath)  
                  images_dict = unpickle(dataPath)
                  
                  # n_iter = 5

                  for k in range(0,len(images_dict[b'data'])):
                    # if(n_iter>0):
                      # print(k)
                      if int(images_dict[b'fine_labels'][k] )<=25 and int(images_dict[b'fine_labels'][k] )>=16:

                        img_R = images_dict[b'data'][k][0:1024].reshape((32, 32))
                        img_G = images_dict[b'data'][k][1024:2048].reshape((32, 32))
                        img_B = images_dict[b'data'][k][2048:3072].reshape((32, 32))
                        img = np.dstack((img_R, img_G, img_B))
                        # plt.figure()

                        # plt.imshow(img)
                        # n_iter-=1
                        img = transforms.ToPILImage()(img )
                        # transforms.ToPILImage(img)    
                        images.append(img)
                        labels.append( int(images_dict[b'fine_labels'][k] ) - 16 )

                      # else:
                        # break
                    
                    # n_iter = 5
                  # for k in images_dict[b'labels']:
                    #if(n_iter>0):
                      # print(k)
                    #  n_iter-=1
                    

                    #else:
                     # break

        self.images = images
        self.labels = labels  



    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]
        # img=Image.open(self.root+'/'+sample)
        target = torch.tensor(int(self.labels[idx]))
       
                                                                                                                                                  
        if self.transform is not None:
            img = self.transform(img)

        return img, target



##################################################

train_ds = CustomDataset( "./cifar-100-python" ,transform = transforms.Compose([ transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)) ]) )
test_ds = CustomDataset( "./cifar-100-python", train = False, transform = transforms.Compose([ transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)) ]) )


##################################################

train_outputs=[]

for data in train_ds:
    outputs1 = fixed_model_2d_loaded(Variable(data[0].view(-1, 3,32,32)))
    # outputs2 = fixed_model_2d_loaded(Variable(images ) )
    
    train_outputs.append(outputs1)

##################################################

id = 0
for data in test_ds:
    #outputs1 = fixed_model_2d_loaded(Variable(data[0].view(-1, 3,32,32)))
    # outputs2 = fixed_model_2d_loaded(Variable(images ) )
    id+=1
    #train_outputs.append(outputs1)

    save_image(data[0], 'test_imgs/img'+str(id)+'.jpg')

id=0
##################################################

@app.route('/')
def form():
    return render_template('form.html')



##################################################

@app.route('/data/', methods = ['POST', 'GET'])
def data():
    if request.method == 'GET':
        return f"The URL /data is accessed directly. Try going to '/form' to submit form"
    if request.method == 'POST':
        # ttl1+=1
        
        form_data = request.form
        id = 0
        paths = []
        classes = []
        
        file1 = request.files['test_img']
        img_bytes1 = file1.read()


        # test_image = Image.fromarray(img_bytes1)
        # actual_class = test_image[1]
        transform = transforms.Compose([ transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)) ])

        test_image = Image.open(io.BytesIO(img_bytes1))
        test_image = transform(test_image)[:3].unsqueeze(0)


        # test_image = transform(test_image)

        good = 0
        bad = 0

        outputs1 = fixed_model_2d_loaded(Variable(test_image .view(-1, 3,32,32)))  
        distances =  [ [] for _ in range(5) ]
        similars = [ [] for _ in range(5) ]

        idx = 0

        for i in range(0,len(train_outputs)):
        

            for model_ind in range(0,5):
                dist = np.linalg.norm(outputs1[model_ind].detach().numpy()- train_outputs[i][model_ind].detach().numpy())
                distances[model_ind].append( [dist,idx] )
            idx+=1

        for model_ind in range(0,5):

            distances[model_ind] = sorted(distances[model_ind], key=lambda x: x[0])
            # print(distances)
            AP = 0
            match = 0
            totl = 0
            

            for nums in range(0,5):
                # print(int( train_ds[ int(distances[model_ind][nums][1]) ][1] ), int(data[1]))
                totl+=1
                # print(int(distances[model_ind][nums][1]))
                
                # similars[model_ind].append(train_ds[int(distances[model_ind][nums][1])])
                img1 = train_ds[int(distances[model_ind][nums][1])][0]
                # img1 = img1.numpy() # TypeError: tensor or list of tensors expected, got <class 'numpy.ndarray'>
                
                classes.append(metaData[b'fine_label_names'][16 +int(train_ds[int(distances[model_ind][nums][1])][1])] )
                save_image(img1, root_path+'/static/img'+str(id)+'.jpg' )
                # cv2.imwrite(root_path+'/static/img'+str(id)+'.jpg',  torch.permute(img1, (1, 2, 0)).numpy() )
                # save_image(img1, '/static/img'+str(id)+'.jpg', normalize = True)
                paths.append('/static/img'+str(id)+'.jpg')
                id+=1

        outputs1 = fixed_model_2d_loaded(Variable(test_image[0].view(-1, 3,32,32)))  
        outputs1 = (outputs1[0]+outputs1[1]+outputs1[2]+outputs1[3]+outputs1[4])/5.0

        distances =  [  ]
        similars = [ ]

        idx = 0

        for i in range(0,len(train_outputs)):
        
            tmp = (train_outputs[i][0] + train_outputs[i][1]+train_outputs[i][2]+train_outputs[i][3]+train_outputs[i][4 ])/5.0

            dist = np.linalg.norm(outputs1.detach().numpy()- tmp.detach().numpy())
                
            # for model_ind in range(0,5):
            # dist = np.linalg.norm(outputs1 .detach().numpy()- train_outputs[i] .detach().numpy())
            distances .append( [dist,idx] )
            idx+=1


        distances = sorted(distances , key=lambda x: x[0])
        # print(distances)
        AP = 0
        match = 0
        totl = 0
        

        for nums in range(0,5):
            # print(int( train_ds[ int(distances[model_ind][nums][1]) ][1] ), int(data[1]))
            totl+=1
            # print(int(distances[model_ind][nums][1]))
            # similars .append(train_ds[int(distances [nums][1])])

            img1 = train_ds[int(distances [nums][1])][0]
            # img1 = img1.numpy() # TypeError: tensor or list of tensors expected, got <class 'numpy.ndarray'>
            paths.append('/static/img'+str(id)+'.jpg')
            
            classes.append(   metaData[b'fine_label_names'][16 + int(train_ds[int(distances [nums][1])] [1]) ]  )
            save_image(img1, root_path+'/static/img'+str(id)+'.jpg' )

            # image = train_img_poac.numpy()
            # cv2.imwrite(root_path+'/static/img'+str(id)+'.jpg', torch.permute(img1, (1, 2, 0)).numpy() )
            
            id+=1

        save_image(test_image, root_path+'/static/img'+str(id)+'.jpg' )
        paths.append('/static/img'+str(id)+'.jpg')
        
        data = {"Classes":classes   ,"paths": paths }
        
        return render_template("result.html",data=data)

app.run(host='localhost', port=5000)

