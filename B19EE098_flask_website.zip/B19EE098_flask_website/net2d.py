import io
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import os

import torch.nn.functional as F

import pdb

class Net2D (nn.Module):
    
    #define the learnable paramters by calling the respective modules (nn.Conv2d, nn.MaxPool2d etc.)
    def __init__(self):
        super(Net2D , self).__init__()
        
        #calling conv3d module for convolution
        self.conv1 = nn.Conv2d(in_channels = 3, out_channels = 50, kernel_size = 2, stride = 1)

        # self.conv1_2 = nn.Conv3d(in_channels = n_frames, out_channels = 50, kernel_size = 2, stride = 1)
        
        #calling MaxPool3d module for max pooling with downsampling of 2
        self.pool1 = nn.MaxPool2d(kernel_size= 2 , stride=2)

        # self.pool1_2 = nn.MaxPool3d(kernel_size=(1, 2, 2), stride=2)

        self.conv2 =  nn.Conv2d(in_channels = 50, out_channels = 100, kernel_size = 3, stride = 1)

        self.pool2 = nn.MaxPool2d(kernel_size= 3 , stride=2)

        # self.conv2_2 =  nn.Conv3d(in_channels = 50, out_channels = 100, kernel_size = (1, 3, 3), stride = 1)

        # self.pool2_2 = nn.MaxPool3d(kernel_size=(1, 3, 3), stride=2)


        # self.conv3  =  nn.Conv2d(in_channels = 100, out_channels = 200, kernel_size = 3 , stride = 1)

        # self.pool3  = nn.MaxPool2d(kernel_size= 3 , stride=2)

        # self.conv3_2 =  nn.Conv3d(in_channels = 100, out_channels = 100, kernel_size = (1, 3, 3), stride = 1)

        # self.pool3_2 = nn.MaxPool3d(kernel_size=(1, 3, 3), stride=2)



        # self.conv2_1 =  nn.Conv2d(in_channels = 50, out_channels = 100, kernel_size = ( 3, 3), stride = 1)

        # self.conv2_2 =  nn.Conv2d(in_channels = 50, out_channels = 100, kernel_size = ( 3, 3), stride = 1)

        # self.pool2_1 = nn.MaxPool2d(kernel_size=( 3, 3), stride=2)

        # self.pool2_2 = nn.MaxPool2d(kernel_size=( 3, 3), stride=2)

        
        
        #fully connected layer
        self.fc1 = nn.Linear(3600, 1200)
        self.fc2 = nn.Linear(1200, 400)
        self.fc2_5 = nn.Linear(400, 36)

        
        self.fc3_0 = nn.Linear(36, 10)
        self.fc3_1 = nn.Linear(36, 10)
        self.fc3_2 = nn.Linear(36, 10)
        self.fc3_3 = nn.Linear(36, 10)
        self.fc3_4 = nn.Linear(36, 10)

        
    
    #defining the structure of the network
    def forward(self, x ):

        x1 = self.pool1 (F.relu(self.conv1 (x)))

        # x2 = self.pool1_2(F.relu(self.conv1_2(y)))

        x1 = self.pool2 (F.relu(self.conv2 (x1)))

        # x2 = self.pool2_2(F.relu(self.conv2_2(x2)))


        # x1 = self.pool3 (F.relu(self.conv3 (x1)))

        # x2 = self.pool3_2(F.relu(self.conv3_2(x2)))

        # x1 = self.pool4_1(F.relu(self.conv4_1(x1)))

        # x2 = self.pool4_2(F.relu(self.conv4_2(x2)))


        # x = torch.cat((x1 ,x2 ),dim=1)

        tmp = 1
        for i in range(1,len(x1.shape))  :
          tmp*=x1.shape[i]

        # print(x1.shape)


        x = x1.view(-1, tmp)

        x = self.fc1(F.relu(x))
        
        x = self.fc2(F.relu(x))
        
        x = self.fc2_5(F.relu(x))

        x0 = self.fc3_0(F.relu(x))
        x1 = self.fc3_1(F.relu(x))
        x2 = self.fc3_2(F.relu(x))
        x3 = self.fc3_3(F.relu(x))
        x4 = self.fc3_4(F.relu(x))
        
        # x = torch.sigmoid(x)

        '''
        
        #Applying relu activation after each conv layer
        x = self.pool1(F.relu(self.conv1(x)))
        x = x.view(-1,50,31,31)
        # pdb.set_trace()
        x = self.pool2(F.relu(self.conv2(x)))
        

        x = torch.cat((x11,x12,x13,x21,x22,x23, x31,x32,x33 ),dim=1)
        
        #reshaping to 1d for giving input to fully connected units
        x = x.view(-1, 19600)
        
        x = self.fc1(F.relu(x))
        
        '''

        return [x0, x1, x2, x3, x4]

fixed_model_2d = Net2D()# .cuda()   #Use .cuda()

#Printing the network architecture
print(fixed_model_2d )
